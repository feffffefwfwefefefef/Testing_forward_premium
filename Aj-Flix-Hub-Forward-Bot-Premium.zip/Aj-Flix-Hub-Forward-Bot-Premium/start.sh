#!/usr/bin/env bash
set -e
# Run health-check/webhook service and the Telegram bot from this repository.
gunicorn --bind 0.0.0.0:${PORT:-10000} app:app &
exec python3 main.py
