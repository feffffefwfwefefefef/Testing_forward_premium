"""Small health-check and Razorpay webhook service used alongside the bot."""
import os, json, hmac, hashlib, time
from flask import Flask, request, abort
from pymongo import MongoClient
from config import Config

app = Flask(__name__)

@app.route('/')
def health():
    return 'Aj Flix Hub Forward Bot is running', 200

@app.route('/health')
def health_check():
    return {'ok': True, 'service': 'aj-flix-hub-forward-bot'}, 200

@app.route('/razorpay-webhook', methods=['POST'])
def razorpay_webhook():
    event_id = None
    secret = Config.RAZORPAY_WEBHOOK_SECRET
    if not secret or not Config.DATABASE_URI:
        abort(503)
    body = request.get_data()
    signature = request.headers.get('X-Razorpay-Signature', '')
    expected = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature):
        abort(400)
    try:
        event = json.loads(body.decode())
    except Exception:
        abort(400)
    if event.get('event') != 'payment_link.paid':
        return {'ok': True, 'ignored': True}, 200
    try:
        entity = event['payload']['payment_link']['entity']
        notes = entity.get('notes') or {}
        user_id, days = int(notes['telegram_user_id']), int(notes['plan_days'])
        link_id = str(entity.get('id') or entity.get('reference_id'))
        if entity.get('status') != 'paid':
            return {'ok': True, 'ignored': True}, 200
        amount = int(entity.get('amount') or 0)
        expected_amounts = {7: 4900, 30: 9900, 90: 24900, 365: 79900}
        if user_id <= 0 or days not in expected_amounts or amount != expected_amounts[days]:
            abort(400)
        db = MongoClient(Config.DATABASE_URI)[Config.DATABASE_NAME]
        # Unique event id prevents repeated webhooks from granting the same plan twice.
        event_id = str(event.get('id') or f"{link_id}:{entity.get('status')}:{entity.get('updated_at')}")
        receipt = db.webhook_events.update_one({'event_id': event_id}, {'$setOnInsert': {'event_id': event_id, 'created_at': time.time()}}, upsert=True)
        if receipt.upserted_id is None:
            return {'ok': True, 'duplicate': True}, 200
        payment_ref = f"razorpay:{link_id}"
        existing = db.payments.find_one({'payment_ref': payment_ref})
        if existing and existing.get('status') == 'approved':
            return {'ok': True, 'already_activated': True}, 200
        user = db.users.find_one({'id': user_id}) or {}
        sub = user.get('subscription') or {}
        now = time.time(); expiry = max(now, float(sub.get('expires_at') or 0)) + days * 86400
        db.users.update_one({'id': user_id}, {'$set': {
            'id': user_id, 'subscription.active': True, 'subscription.plan_days': days,
            'subscription.started_at': now, 'subscription.expires_at': expiry,
            'subscription.payment_ref': payment_ref}}, upsert=True)
        db.payments.update_one({'payment_ref': payment_ref}, {'$set': {
            'user_id': user_id, 'days': days, 'status': 'approved', 'gateway': 'razorpay',
            'amount_paise': amount, 'created_at': now}}, upsert=True)
        # Notify the user through Telegram after the database grant succeeds.
        if Config.BOT_TOKEN:
            import urllib.request
            note = (f"Premium activated! Your {days}-day Aj Flix Hub Premium subscription is active. "
                    f"Use /premiumstatus to check it.")
            req = urllib.request.Request(
                f"https://api.telegram.org/bot{Config.BOT_TOKEN}/sendMessage",
                data=json.dumps({'chat_id': user_id, 'text': note}).encode(),
                headers={'Content-Type': 'application/json'}, method='POST')
            try:
                urllib.request.urlopen(req, timeout=8).read()
            except Exception:
                app.logger.warning('Premium granted but Telegram notification failed for %s', user_id)
        return {'ok': True}, 200
    except (KeyError, TypeError, ValueError):
        abort(400)
    except Exception:
        if event_id:
            try:
                MongoClient(Config.DATABASE_URI)[Config.DATABASE_NAME].webhook_events.delete_one({'event_id': event_id})
            except Exception:
                pass
        app.logger.exception('Webhook processing failed')
        return {'ok': False}, 500
