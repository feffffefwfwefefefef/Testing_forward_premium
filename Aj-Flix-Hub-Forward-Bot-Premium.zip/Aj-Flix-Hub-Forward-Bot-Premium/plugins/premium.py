"""Premium subscription commands for Aj Flix Hub Forward Bot.

Manual UPI flow: /paid UTR -> owner verifies in bank app -> /approve USER_ID DAYS UTR
Automatic Razorpay Payment Links are enabled when API credentials are configured.
"""
import asyncio
import base64
import json
import time
import urllib.request
import urllib.error
from datetime import datetime
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import Config
from database import db

PLANS = {7: 49, 30: 99, 90: 249, 365: 799}

async def make_razorpay_link(user_id: int, days: int, amount_rupees: int):
    if not (Config.RAZORPAY_KEY_ID and Config.RAZORPAY_KEY_SECRET):
        return None
    def request_link():
        auth = base64.b64encode(f"{Config.RAZORPAY_KEY_ID}:{Config.RAZORPAY_KEY_SECRET}".encode()).decode()
        payload = {
            "amount": amount_rupees * 100, "currency": "INR",
            "accept_partial": False, "description": f"Aj Flix Hub Premium - {days} days",
            "reference_id": f"ajflix-{user_id}-{int(time.time())}",
            "customer": {}, "notify": {"sms": False, "email": False},
            "reminder_enable": False,
            "notes": {"telegram_user_id": str(user_id), "plan_days": str(days)}
        }
        req = urllib.request.Request(
            "https://api.razorpay.com/v1/payment_links",
            data=json.dumps(payload).encode(),
            headers={"Authorization": f"Basic {auth}", "Content-Type": "application/json"},
            method="POST")
        with urllib.request.urlopen(req, timeout=20) as response:
            return json.loads(response.read().decode())
    try:
        return await asyncio.to_thread(request_link)
    except Exception:
        return None

@Client.on_message(filters.private & filters.command(["premium", "plans"]))
async def premium_menu(client, message):
    user_id = message.from_user.id
    sub = await db.get_subscription(user_id)
    expiry = datetime.fromtimestamp(float(sub.get('expires_at', 0))).strftime('%d-%m-%Y %H:%M IST') if sub.get('active') else 'Not active'
    text = (
        "<b>💎 AJ FLIX HUB PREMIUM</b>\n\n"
        "<b>Premium features</b>\n"
        "• Multiple destination channels\n• Multiple source channels\n"
        "• Custom forwarding delay\n• Advanced caption/filter settings\n"
        "• Duplicate filtering, progress and statistics\n• Persistent settings and restart recovery\n\n"
        f"<b>Your Premium:</b> {'ACTIVE' if sub.get('active') else 'FREE'}\n"
        f"<b>Expires:</b> {expiry}\n\n"
        "<b>Plans</b>\n7 days — ₹49\n30 days — ₹99\n90 days — ₹249\n365 days — ₹799\n\n"
        "Choose a plan below. Prices are configurable in plugins/premium.py.")
    buttons = [[InlineKeyboardButton(f"7 Days · ₹49", callback_data="prembuy_7"), InlineKeyboardButton("30 Days · ₹99", callback_data="prembuy_30")],
               [InlineKeyboardButton("90 Days · ₹249", callback_data="prembuy_90"), InlineKeyboardButton("365 Days · ₹799", callback_data="prembuy_365")]]
    if Config.UPI_ID:
        buttons.append([InlineKeyboardButton("Manual UPI instructions", callback_data="premupi")])
    await message.reply_text(text, reply_markup=InlineKeyboardMarkup(buttons))

@Client.on_callback_query(filters.regex(r'^prembuy_(7|30|90|365)$'))
async def premium_buy(client, query):
    days = int(query.data.split('_')[1]); amount = PLANS[days]
    link = await make_razorpay_link(query.from_user.id, days, amount)
    if link and link.get('short_url'):
        ref = link.get('id') or link.get('reference_id')
        await db.save_payment(f"razorpay:{ref}", query.from_user.id, days, 'pending')
        await query.message.reply_text(
            f"<b>💳 Payment checkout</b>\nPlan: {days} days\nAmount: ₹{amount}\n\n"
            "Pay using the secure checkout link. Premium activates only after the verified payment webhook arrives.\n\n"
            f"<a href='{link['short_url']}'>Pay securely</a>", disable_web_page_preview=True)
    elif Config.UPI_ID:
        await query.message.reply_text(
            f"<b>Manual UPI payment</b>\nPlan: {days} days · ₹{amount}\n\n"
            f"UPI ID: <code>{Config.UPI_ID}</code>\n\nAfter paying, send <code>/paid YOUR_UTR</code>. Admin verifies the actual bank transaction before activation.")
    else:
        await query.answer("Payments are not configured yet. Please contact the bot admin.", show_alert=True)

@Client.on_callback_query(filters.regex(r'^premupi$'))
async def premium_upi(client, query):
    if not Config.UPI_ID:
        return await query.answer("UPI ID is not configured.", show_alert=True)
    await query.message.reply_text(
        "<b>Manual UPI payment</b>\nChoose a plan using /premium, pay the exact amount to:\n"
        f"<code>{Config.UPI_ID}</code>\n\nThen send <code>/paid YOUR_UTR</code>. Do not send only a screenshot; payment must be verified in the bank app.")

@Client.on_message(filters.private & filters.command("paid"))
async def submit_payment(client, message):
    parts = (message.text or '').split(maxsplit=1)
    if len(parts) != 2 or len(parts[1].strip()) < 6:
        return await message.reply_text("Usage: <code>/paid YOUR_UTR</code>\nChoose a plan with /premium first, then send the transaction UTR.")
    utr = parts[1].strip()
    await db.save_payment(utr, message.from_user.id, 0, 'awaiting_admin')
    for admin_id in Config.PREMIUM_ADMIN_IDS:
        try:
            await client.send_message(admin_id,
                f"<b>💳 Manual payment review</b>\nUser: <code>{message.from_user.id}</code>\n"
                f"UTR: <code>{utr}</code>\n\nAfter verifying the actual bank transaction, approve with:\n"
                f"<code>/approve {message.from_user.id} DAYS {utr}</code>")
        except Exception:
            pass
    await message.reply_text("Payment reference sent to the admin for verification. Premium will not activate until the actual payment is confirmed.")

@Client.on_message(filters.private & filters.command("approve") & filters.user(Config.PREMIUM_ADMIN_IDS))
async def approve_payment(client, message):
    parts = (message.text or '').split(maxsplit=3)
    if len(parts) != 4:
        return await message.reply_text("Usage: <code>/approve USER_ID DAYS UTR</code>")
    try:
        user_id, days = int(parts[1]), int(parts[2]); utr = parts[3].strip()
        if days not in (7, 30, 90, 365): raise ValueError
    except ValueError:
        return await message.reply_text("Invalid user ID or plan days. Allowed plans: 7, 30, 90, 365.")
    payment = await db.payments.find_one({'payment_ref': utr, 'user_id': user_id})
    if not payment:
        return await message.reply_text("No matching payment submission found. Ask the user to submit /paid UTR first.")
    if payment.get('status') == 'approved':
        return await message.reply_text("This payment reference has already been approved.")
    await db.payments.update_one({'payment_ref': utr}, {'$set': {'days': days, 'status': 'approved', 'approved_by': message.from_user.id, 'approved_at': time.time()}})
    expires = await db.grant_premium(user_id, days, utr)
    await client.send_message(user_id, f"🎉 <b>Premium activated!</b>\nPlan: {days} days\nExpiry timestamp: <code>{int(expires)}</code>\nUse /premium to check your status.")
    await message.reply_text(f"Approved. Premium activated for <code>{user_id}</code> for {days} days.")

@Client.on_message(filters.private & filters.command("premiumstatus"))
async def premium_status(client, message):
    sub = await db.get_subscription(message.from_user.id)
    if not sub.get('active'):
        return await message.reply_text("Your Premium is not active. Use /premium to view plans.")
    expiry = datetime.fromtimestamp(float(sub['expires_at'])).strftime('%d-%m-%Y %H:%M')
    await message.reply_text(f"💎 <b>Premium Active</b>\nExpires: <code>{expiry}</code>")

@Client.on_message(filters.private & filters.command("delay"))
async def set_forward_delay(client, message):
    sub = await db.get_subscription(message.from_user.id)
    if not sub.get('active'):
        return await message.reply_text("⏱️ Custom Delay is a Premium feature. Use /premium to choose a plan.")
    parts = (message.text or '').split(maxsplit=1)
    if len(parts) != 2:
        cfg = await db.get_configs(message.from_user.id)
        return await message.reply_text(
            f"Current delay: <b>{cfg.get('custom_delay', 1)} seconds</b>\n"
            "Set it with <code>/delay 5</code> (0–3600 seconds).")
    try:
        seconds = int(parts[1])
        if seconds < 0 or seconds > 3600:
            raise ValueError
    except ValueError:
        return await message.reply_text("Enter a whole number from 0 to 3600. Example: <code>/delay 5</code>")
    cfg = await db.get_configs(message.from_user.id)
    cfg['custom_delay'] = seconds
    await db.update_configs(message.from_user.id, cfg)
    await message.reply_text(f"✅ Custom delay saved: <b>{seconds} seconds</b> between copied messages.")
