# Aj Flix Hub Forward Bot — Premium Setup (தமிழ்)

இந்த ZIP-ல் தற்போதைய Bot code-க்கு Premium subscription வசதிகள் சேர்க்கப்பட்டுள்ளன. Deploy செய்யும் முன் கீழே உள்ள Environment Variables-ஐ Koyeb-ல் அமைக்கவும்.

## 1. Koyeb Environment Variables

கட்டாயம்:
- `API_ID` — my.telegram.org-ல் பெறுவது
- `API_HASH` — my.telegram.org-ல் பெறுவது
- `BOT_TOKEN` — @BotFather
- `BOT_OWNER_ID` — உங்கள் Telegram numeric user ID
- `DATABASE_URI` — MongoDB connection string
- `DATABASE_NAME` — `AjFlixHub` அல்லது உங்கள் DB பெயர்
- `LOG_CHANNEL` — bot log channel ID
- `FORCE_SUB_CHANNEL` — force-sub channel link/username
- `FORCE_SUB_ON` — `True` அல்லது `False`

Manual UPI விருப்பம்:
- `UPI_ID` — உங்கள் UPI ID
- `PREMIUM_ADMIN_IDS` — Premium payment approve செய்ய அனுமதிக்கப்படும் Telegram user ID-கள்; space-separated. காலியாக விட்டால் `BOT_OWNER_ID` பயன்படுத்தப்படும்.

Automatic Razorpay விருப்பம்:
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `RAZORPAY_WEBHOOK_SECRET`

## 2. Koyeb Run Command

```bash
gunicorn --bind 0.0.0.0:$PORT app:app & python3 main.py
```

Build command: `pip install -r requirements.txt`

## 3. Bot Commands

- `/premium` — Plans மற்றும் subscription நிலை
- `/premiumstatus` — Premium expiry நிலை
- `/delay 5` — Premium user-க்கு ஒவ்வொரு copied message-க்கும் 5-second delay (0–3600)
- `/forward` — forwarding flow; Premium user பல target channels தேர்ந்தெடுத்தால் `ALL DESTINATIONS (Premium)` தேர்வு செய்யலாம்
- `/paid UTR` — manual UPI payment reference அனுப்புதல்
- `/approve USER_ID DAYS UTR` — உண்மையான bank transaction சரிபார்த்த பிறகே Admin approve செய்ய வேண்டும். `DAYS`: 7, 30, 90, 365.

Plan prices (`plugins/premium.py`): ₹49 / 7 days, ₹99 / 30 days, ₹249 / 90 days, ₹799 / 365 days. விலையை மாற்றினால் `app.py`-ல் உள்ள webhook amount validation-ஐயும் அதேபடி மாற்ற வேண்டும்.

## 4. Razorpay Automatic Payment

1. Razorpay account-ல் API keys உருவாக்கவும்.
2. Koyeb public URL-க்கு `/razorpay-webhook` சேர்த்து Webhook URL அமைக்கவும்.
3. `payment_link.paid` event-ஐ enable செய்யவும்.
4. Webhook secret-ஐ `RAZORPAY_WEBHOOK_SECRET`-ல் அமைக்கவும்.
5. முதலில் Razorpay Test Mode-ல் முழுமையாகச் சோதிக்கவும்; பிறகு மட்டுமே Live Mode பயன்படுத்தவும்.

Webhook signature, plan days, amount ஆகியவை சரிபார்க்கப்படும். Database-ல் payment/subscription பதிவு செய்த பிறகு Telegram notification அனுப்பப்படும்.

## 5. முக்கிய பாதுகாப்பு

- MongoDB-ஐ persistent external database ஆகப் பயன்படுத்தவும்; Koyeb temporary filesystem-ல் subscription data வைக்க வேண்டாம்.
- Telegram token, MongoDB URI/password, Razorpay secrets ஆகியவற்றை GitHub-ல் commit செய்ய வேண்டாம்.
- பழைய source `config.py`-ல் MongoDB username/password நேரடியாக இருந்தது. அந்த credential ஏற்கெனவே GitHub-க்கு push செய்யப்பட்டிருந்தால் MongoDB Atlas-ல் password-ஐ உடனே மாற்றி புதிய `DATABASE_URI` அமைக்கவும்.
- UPI Screenshot மட்டும் பார்த்து approve செய்ய வேண்டாம்; bank statement-ல் UTR மற்றும் amount சரிபார்க்கவும்.
- Payment gateway-ன் live payment availability, fees மற்றும் merchant verification தேவைகள் provider-ஐப் பொறுத்து மாறலாம்.
