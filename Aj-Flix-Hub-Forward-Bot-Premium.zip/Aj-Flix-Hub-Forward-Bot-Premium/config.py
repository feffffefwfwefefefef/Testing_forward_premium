# bot developer @im_jisshu
from os import environ 

class Config:
    
    API_ID = environ.get("API_ID", "28814392")
    API_HASH = environ.get("API_HASH", "38d09c28822aa20a56c43c4b492efba6")
    BOT_TOKEN = environ.get("BOT_TOKEN", "") 
    BOT_OWNER_ID = [int(id) for id in environ.get("BOT_OWNER_ID", '7228509851').split()]
    BOT_SESSION = environ.get("BOT_SESSION", "bot") 

    PICS = (environ.get('PICS', 'https://ibb.co/rGVY9VWs'))
    
    # Set DATABASE_URI and DATABASE_NAME in your hosting environment. Never commit credentials.
    DATABASE_URI = environ.get("DATABASE_URI", "")
    DATABASE_NAME = environ.get("DATABASE_NAME", "AjFlixHub")

    # Premium payments: set Razorpay credentials to enable automatic checkout/webhooks.
    RAZORPAY_KEY_ID = environ.get("RAZORPAY_KEY_ID", "")
    RAZORPAY_KEY_SECRET = environ.get("RAZORPAY_KEY_SECRET", "")
    RAZORPAY_WEBHOOK_SECRET = environ.get("RAZORPAY_WEBHOOK_SECRET", "")
    UPI_ID = environ.get("UPI_ID", "")
    PREMIUM_ADMIN_IDS = [int(x) for x in environ.get("PREMIUM_ADMIN_IDS", "").split() if x.isdigit()] or BOT_OWNER_ID
    
    LOG_CHANNEL = int(environ.get('LOG_CHANNEL', '-1003952418809'))
    FORCE_SUB_CHANNEL = environ.get("FORCE_SUB_CHANNEL", "https://t.me/Aj_Flix_Hub") # FORCE SUB channel link 
    FORCE_SUB_ON = environ.get("FORCE_SUB_ON", "True")  # FORCE SUB ON - OFF


class temp(object): 
    lock = {}
    CANCEL = {}
    forwardings = 0
    BANNED_USERS = []
    IS_FRWD_CHAT = []
    FORWARD_TASKS = {}
    
