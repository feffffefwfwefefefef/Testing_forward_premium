# bot developer @im_jisshu
from os import environ 
from config import Config
import motor.motor_asyncio
from pymongo import MongoClient

async def mongodb_version():
    x = MongoClient(Config.DATABASE_URI)
    mongodb_version = x.server_info()['version']
    return mongodb_version

class Database:
    
    def __init__(self, uri, database_name):
        self._client = motor.motor_asyncio.AsyncIOMotorClient(uri)
        self.db = self._client[database_name]
        self.bot = self.db.bots
        self.col = self.db.users
        self.nfy = self.db.notify
        self.chl = self.db.channels
        self.payments = self.db.payments 
        
    def new_user(self, id, name):
        return dict(
            id = id,
            name = name,
            ban_status=dict(
                is_banned=False,
                ban_reason="",
            ),
        )
      
    async def add_user(self, id, name):
        user = self.new_user(id, name)
        await self.col.insert_one(user)
    
    async def is_user_exist(self, id):
        user = await self.col.find_one({'id':int(id)})
        return bool(user)
    
    async def total_users_bots_count(self):
        bcount = await self.bot.count_documents({})
        count = await self.col.count_documents({})
        return count, bcount

    async def total_channels(self):
        count = await self.chl.count_documents({})
        return count
    
    async def remove_ban(self, id):
        ban_status = dict(
            is_banned=False,
            ban_reason=''
        )
        await self.col.update_one({'id': id}, {'$set': {'ban_status': ban_status}})
    
    async def ban_user(self, user_id, ban_reason="No Reason"):
        ban_status = dict(
            is_banned=True,
            ban_reason=ban_reason
        )
        await self.col.update_one({'id': user_id}, {'$set': {'ban_status': ban_status}})

    async def get_ban_status(self, id):
        default = dict(
            is_banned=False,
            ban_reason=''
        )
        user = await self.col.find_one({'id':int(id)})
        if not user:
            return default
        return user.get('ban_status', default)

    async def get_all_users(self):
        return self.col.find({})
    
    async def delete_user(self, user_id):
        await self.col.delete_many({'id': int(user_id)})
 
    async def get_banned(self):
        users = self.col.find({'ban_status.is_banned': True})
        b_users = [user['id'] async for user in users]
        return b_users

    async def update_configs(self, id, configs):
        await self.col.update_one({'id': int(id)}, {'$set': {'configs': configs}})
         
    async def get_configs(self, id):
        default = {
            'caption': None,
            'custom_delay': 1,
            'duplicate': True,
            'forward_tag': False,
            'file_size': 0,
            'size_limit': None,
            'extension': None,
            'keywords': None,
            'protect': None,
            'button': None,
            'db_uri': None,
            'filters': {
               'poll': True,
               'text': True,
               'audio': True,
               'voice': True,
               'video': True,
               'photo': True,
               'document': True,
               'animation': True,
               'sticker': True
            }
        }
        user = await self.col.find_one({'id':int(id)})
        if user:
            saved = user.get('configs') or {}
            # Keep old users compatible when new settings are added.
            config = dict(default)
            config.update(saved)
            saved_filters = saved.get('filters') or {}
            config['filters'] = dict(default['filters'])
            config['filters'].update(saved_filters)
            return config
        return default 
       
    async def add_bot(self, datas):
       # Allow multiple bots/userbots per owner. Prevent the same Telegram
       # account from being added twice.
       existing = await self.bot.find_one({
           'user_id': int(datas['user_id']),
           'id': int(datas['id'])
       })
       if existing:
          return False
       await self.bot.insert_one(datas)
       return True
    
    async def remove_bot(self, user_id, bot_id=None):
       if bot_id is None:
          return await self.bot.delete_many({'user_id': int(user_id)})
       return await self.bot.delete_one({
           'user_id': int(user_id),
           'id': int(bot_id)
       })
      
    async def get_bots(self, user_id: int):
       cursor = self.bot.find({'user_id': int(user_id)}).sort('name', 1)
       return [bot async for bot in cursor]

    async def get_bot_by_id(self, user_id: int, bot_id: int):
       return await self.bot.find_one({
           'user_id': int(user_id),
           'id': int(bot_id)
       })

    async def get_bot(self, user_id: int):
       # Backward-compatible default account: first saved account.
       bot = await self.bot.find_one({'user_id': int(user_id)})
       return bot if bot else None
                                          
    async def is_bot_exist(self, user_id, bot_id=None):
       query = {'user_id': int(user_id)}
       if bot_id is not None:
          query['id'] = int(bot_id)
       bot = await self.bot.find_one(query)
       return bool(bot)
                                          
    async def in_channel(self, user_id: int, chat_id: int) -> bool:
       channel = await self.chl.find_one({"user_id": int(user_id), "chat_id": int(chat_id)})
       return bool(channel)
    
    async def add_channel(self, user_id: int, chat_id: int, title, username):
       channel = await self.in_channel(user_id, chat_id)
       if channel:
         return False
       return await self.chl.insert_one({"user_id": user_id, "chat_id": chat_id, "title": title, "username": username})
    
    async def remove_channel(self, user_id: int, chat_id: int):
       channel = await self.in_channel(user_id, chat_id )
       if not channel:
         return False
       return await self.chl.delete_many({"user_id": int(user_id), "chat_id": int(chat_id)})
    
    async def get_channel_details(self, user_id: int, chat_id: int):
       return await self.chl.find_one({"user_id": int(user_id), "chat_id": int(chat_id)})
       
    async def get_user_channels(self, user_id: int):
       channels = self.chl.find({"user_id": int(user_id)})
       return [channel async for channel in channels]
     
    async def get_filters(self, user_id):
       filters = []
       filter = (await self.get_configs(user_id))['filters']
       for k, v in filter.items():
          if v == False:
            filters.append(str(k))
       return filters
              
    async def add_frwd(self, user_id, forward_id=None, state=None):
       doc = {'user_id': int(user_id)}
       if forward_id is not None:
          doc['forward_id'] = str(forward_id)
       if state:
          doc.update(state)
       return await self.nfy.update_one(
           {'user_id': int(user_id)},
           {'$set': doc},
           upsert=True
       )

    async def update_frwd(self, user_id, state):
       return await self.nfy.update_one(
           {'user_id': int(user_id)},
           {'$set': state}
       )

    async def rmve_frwd(self, user_id=0, all=False):
       data = {} if all else {'user_id': int(user_id)}
       return await self.nfy.delete_many(data)

    async def get_all_frwd(self):
       return self.nfy.find({})
     
    async def get_subscription(self, user_id: int):
        user = await self.col.find_one({'id': int(user_id)}) or {}
        sub = user.get('subscription') or {}
        expiry = sub.get('expires_at', 0)
        active = bool(sub.get('active')) and float(expiry or 0) > __import__('time').time()
        if sub.get('active') and not active:
            await self.col.update_one({'id': int(user_id)}, {'$set': {'subscription.active': False}})
        return {**sub, 'active': active}

    async def grant_premium(self, user_id: int, days: int, payment_ref: str = 'admin-approved'):
        import time
        now = time.time()
        current = await self.get_subscription(user_id)
        start_from = max(now, float(current.get('expires_at', 0) or 0))
        expires = start_from + max(1, int(days)) * 86400
        await self.col.update_one({'id': int(user_id)}, {'$set': {
            'subscription.active': True, 'subscription.plan_days': int(days),
            'subscription.started_at': now, 'subscription.expires_at': expires,
            'subscription.payment_ref': str(payment_ref)}} , upsert=True)
        await self.payments.update_one({'payment_ref': str(payment_ref)}, {'$setOnInsert': {
            'user_id': int(user_id), 'days': int(days), 'status': 'approved', 'created_at': now}}, upsert=True)
        return expires

    async def save_payment(self, payment_ref: str, user_id: int, days: int, status: str = 'pending'):
        import time
        await self.payments.update_one({'payment_ref': str(payment_ref)}, {'$setOnInsert': {
            'user_id': int(user_id), 'days': int(days), 'status': status, 'created_at': time.time()}}, upsert=True)


if not Config.DATABASE_URI:
    raise RuntimeError("DATABASE_URI is required. Set it in Koyeb Environment Variables.")

db = Database(Config.DATABASE_URI, Config.DATABASE_NAME)
