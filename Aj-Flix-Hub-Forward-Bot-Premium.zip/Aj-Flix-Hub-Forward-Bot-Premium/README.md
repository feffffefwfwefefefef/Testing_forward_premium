<p align="center">
<img src="https://files.catbox.moe/uevfz8.jpg"/>

<hr>

# FEATURES
 - Forward Messages From Public & Private Channels.
 - Supports Broadcasts.
 - Custom Caption & Buttons.
 - Support Restricted Chats.
 - Skip Duplicate Messages.
 - Message Type Filters.
 - Filter By Extensions, Keywords & File Size.
 - Multiple Source & Target Channels.
 - Forward Videos, Photos, Documents & Other Media.
 - Forwarding Progress & Statistics.
 - MongoDB Database Support.
 - Docker Support.
<details>
 
<summary>More Features</summary>
 
<br>
 
 - Custom Forward Tags.
 - Skip Specific Messages.
 - Cancel Running Forward Tasks.
 - Protected Message Support.
 - Userbot/Pyrogram Session Support.
 - Configurable Forwarding Filters.
 - Duplicate File Detection.
 - Database-Based Message Tracking.

</details>

<hr>

# CONFIGS VARIABLES

Set these variables before starting the bot.

| Variable | Required | Description |
|---|---|---|
| `API_ID` | Yes | Telegram API ID from Telegram |
| `API_HASH` | Yes | Telegram API hash |
| `BOT_TOKEN` | Yes | Bot token from BotFather |
| `BOT_OWNER_ID` | Yes | Admin/owner Telegram user ID(s), separated by spaces |
| `BOT_SESSION` | No | Bot session name. Default: `bot` |
| `PICS` | No | Start/help image URL |
| `DATABASE_URI` | Yes | MongoDB connection URI |
| `DATABASE_NAME` | No | MongoDB database name. Default: `Cluster0` |
| `LOG_CHANNEL` | Yes | Telegram log channel ID |
| `FORCE_SUB_CHANNEL` | Yes* | Force-subscription channel URL/username |
| `FORCE_SUB_ON` | No | Enable/disable force subscription. Default: `True` |

<hr>

# Files

```text
Jisshu-Forward-Bot/
├── Dockerfile
├── Procfile
├── app.json
├── app.py
├── bot.py
├── config.py
├── database.py
├── heroku.yml
├── logging.conf
├── main.py
├── requirements.txt
├── start.sh
├── translation.py
└── plugins/
    ├── broadcast.py
    ├── commands.py
    ├── public.py
    ├── regix.py
    ├── settings.py
    ├── test.py
    ├── unequify.py
    └── utils.py
```

<hr>

# DEPLOYEMENT SUPPORT
## Koyeb

```text
Build:
pip3 install -U -r requirements.txt

Run:
python3 main.py
```

## Render

```text
Build:
pip3 install -U -r requirements.txt

Start:
gunicorn app:app & python3 main.py
```

## VPS

```bash
sudo apt update
sudo apt install -y git python3 python3-pip python3-venv

git clone https://github.com/Jisshubot/Jisshu-forward-bot.git
cd Jisshu-forward-bot

python3 -m venv venv
source venv/bin/activate

pip3 install -U -r requirements.txt

python3 main.py
```
<hr>

# ALL COMMANDS

```
start - Start the bot.
forward - Forward messages.
unequify - Delete dublicate files in channel.
settings - Configure your settings.
cancel - Cancel ongoing forwarding.
stats - To check bot stats (Admin Only)
resetall - To reset all user settings. (Admin Only)
broadcast - To broadcast any message to all users (Admin Only)
restart - Restart the bot (Admin Only)
```

## Developer

**ZISHAN / JISSHU BOTS**

<hr>

<p align="center">
  Built with ❤️ by <b>Zishan Khan</b>
</p>

<p align="center">
  📢 <a href="https://t.me/jisshubots">Updates Channel</a>
  &nbsp; • &nbsp;
  💬 <a href="https://t.me/Jisshu_support">Support Group</a>
  &nbsp; • &nbsp;
  👤 <a href="https://t.me/JisshuDeveloperBot">Admin</a>
</p>

<p align="center">
  ⭐ If you find this project useful, don't forget to star the repository!
</p>


## Aj Flix Hub Premium additions

- `/premium` or `/plans`: show Premium plans and current access.
- `/premiumstatus`: show active Premium status.
- `/delay 5`: set the per-message delay in seconds (Premium only; 0–3600).
- Premium users can choose **ALL DESTINATIONS (Premium)** in `/forward` to send to every saved target channel.
- `/paid UTR`: submit a manual UPI payment reference for review.
- `/approve USER_ID DAYS UTR`: owner/admin activates a manually verified plan (allowed days: 7, 30, 90, 365).
- Forwarding jobs are persisted and restored on process restart by the existing recovery logic.

### Required Koyeb Environment Variables

Keep credentials in Koyeb Environment Variables, not in source files:

- `API_ID`, `API_HASH`, `BOT_TOKEN`, `BOT_OWNER_ID`
- `DATABASE_URI`, `DATABASE_NAME`
- `LOG_CHANNEL`, `FORCE_SUB_CHANNEL`, `FORCE_SUB_ON`
- `UPI_ID` (optional, for manual UPI instructions)
- `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET` (optional, for automatic payments)
- `PREMIUM_ADMIN_IDS` (optional; space-separated Telegram user IDs; defaults to `BOT_OWNER_ID`)

Set the Koyeb Run command to:

```bash
gunicorn --bind 0.0.0.0:$PORT app:app & python3 main.py
```

For automatic Razorpay activation, configure a Razorpay Payment Link webhook to the public Koyeb URL plus `/razorpay-webhook`, subscribe to `payment_link.paid`, and set the webhook secret in `RAZORPAY_WEBHOOK_SECRET`. Test with Razorpay test mode before accepting live payments. Payment activation is based on a verified webhook signature and a matching plan amount.

The plan prices are examples in `plugins/premium.py`: ₹49 / 7 days, ₹99 / 30 days, ₹249 / 90 days, ₹799 / 365 days. If prices change, update the plan table there and the matching amount validation in `app.py` together.

**Important:** use a persistent MongoDB database. Do not rely on a temporary container filesystem for subscription or forwarding data.
